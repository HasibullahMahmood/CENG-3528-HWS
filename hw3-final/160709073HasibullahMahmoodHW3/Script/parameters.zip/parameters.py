
chromeWebDriverPath = 'D:\chromedriver'


linkedIn_login_page = 'https://www.linkedin.com/login?fromSignIn=true&trk=guest_homepage-basic_nav-header-signin'

googleUrl = 'https://www.google.com'

# login details
in_email = 'tomandjerryhaks@gmail.com'
in_password = 'hasibishacking'

# Search details
google_search_query = 'site:linkedin.com/in/ AND "Software Engineer" AND "Berlin"'

# CSV file name
csv_file_name='LinkedIn_Profiles_Info.csv'
